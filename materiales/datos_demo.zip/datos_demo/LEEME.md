# Datos de demostración 100% sintéticos

Este paquete fue creado desde cero para una entrevista. Ninguna fila de los archivos originales fue copiada ni transformada. De los tres CSV compartidos se conservaron únicamente los encabezados para mantener el formato de lectura. Los nombres de grupos, equipos, personas, identificadores, fechas, coordenadas, lecturas y volúmenes se inventaron de forma determinista.

Periodo ficticio: **7–20 de abril de 2025**. Las series de nivel incluyen el cierre del 20 de abril, representado por el 21 de abril a las 00:00. Los grupos ficticios son Operación Aurora Demo, Contratista Boreal Demo y Contratista Cobalto Demo.

## Archivos e importación

| Archivo | Contenido | Uso |
|---|---|---|
| DEMO_equipment_items.csv | 33 registros, 53 columnas | Maestro para OverfillSflSpy, IntakeVersusDelivery y SweeperAndMop |
| DEMO_dispensing_transactions.csv | 336 despachos, 60 columnas | Transacciones para los tres analizadores |
| DEMO_transfer_transactions.csv | 42 transferencias, 32 columnas | Transacciones para los tres analizadores |
| DEMO_delivery_transactions.csv | 14 recepciones, 20 columnas | Entrada faltante simulada para HMI |
| DEMO_stock_trend_20250421000000000.csv | 113 timestamps cada 3 horas, 4 filas de metadatos | Tendencia de inventario para HMI; el nombre incluye una hora ficticia de generación |
| DEMO_historical_tank_volumes.csv | 1.685 lecturas horarias de 5 tanques | Lecturas de nivel simuladas para HMI |
| DEMO_fleet_form_submissions.xlsx | 42 formularios; hoja Form Submissions | Importación de formularios en Fleet Maintenance |
| DEMO_fleet_master.xlsx | 12 inspecciones previas; tabla Table3 y referencias Table33/Table4 | Importación de histórico en Fleet Maintenance |
| DEMO_fleet_tag_movements.xlsx | 32 movimientos TAG/SMU; 8 por tipo | Importación de movimientos en Fleet Maintenance |
| DEMO_fleet_form_submissions.csv | Respaldo tabular de los formularios | Consulta; Fleet importa el XLSX |
| DEMO_fleet_master_full_list.csv | Respaldo tabular del maestro | Consulta; Fleet importa el XLSX |
| DEMO_fleet_tag_movements.csv | Respaldo tabular de los movimientos | Consulta; Fleet importa el XLSX |
| demo_model.json | Datos sintéticos y resumen compartido | Base de las demostraciones web y gráficas de la presentación |

Los CSV usan UTF-8 con BOM, separador de columnas coma, números con punto decimal y fechas `dd/mm/yyyy HH:MM:SS`. Se mantienen campos vacíos cuando representan ausencia de un valor; no se reemplazan por cero.

## Precaución concreta antes de usar las aplicaciones originales

Las aplicaciones originales incluyen nombres, códigos, mapas de grupos y topologías de la operación en su interfaz, configuración y, en algunos casos, en bases de datos guardadas. **Importar estos CSV por sí solo no elimina esos rótulos ni el histórico local.** Para la entrevista utiliza la página web de demostración entregada, que recrea los casos con información ficticia.

Si se desea demostrar las aplicaciones originales, primero se necesita una copia aislada y sanitizada, con una base local vacía. La topología fija de HMI debe sustituirse por los tanques `DEMO - Main Tank`, `DEMO - Virtual Tank` y `DEMO - D01-TK-01/02/03`, junto con las capacidades ficticias del JSON. La regla de grupo propietario y de categoría liviana en SweeperAndMop debe usar `DEMO_AURORA` y `D-LV`. Estos ajustes se utilizaron únicamente en memoria durante la validación; no se modificaron los archivos de los proyectos originales.

En Fleet Maintenance se mantuvo el nombre técnico de la hoja `Full List 2024-2025` porque el lector lo exige. Todo su contenido corresponde al periodo ficticio de abril de 2025. No es un histórico de la empresa.

## Casos incluidos

La flota ilustrativa contiene 24 equipos y 42 revisiones: todos los equipos aparecen al menos una vez. Se agregaron 9 registros de distribución y almacenamiento para mantener coherencia con las transferencias. Las 32 acciones de TAG/SMU incluyen instalación, reemplazo, retiro y actualización en cantidades iguales.

Los dos camiones ficticios reciben y entregan producto mediante identificadores relacionados. El remanente positivo representa cambio de inventario dentro de esta simulación; no se presenta como pérdida ni como indicador real de desempeño.

| Nodo ficticio | Ingreso (L) | Entrega (L) | Diferencia (L) |
|---|---:|---:|---:|
| TFL9901 | 32.219 | 29.699 | 2.520 |
| TFL9902 | 35.991 | 33.561 | 2.430 |

Se sembraron dos despachos de 150 y 157 L hacia `DLV-302`, cuyo SFL ficticio es 110 L: excesos de 40 y 47 L. Otro equipo no tiene SFL de diésel y produce 14 operaciones sin límite para ilustrar el punto ciego.

Para calidad de datos se sembraron 7 inconsistencias: 3 de tiempo/flujo y 4 de maestro. El analizador encontró 8 hallazgos porque una regla adicional también se activa con estos datos. Los hallazgos son casos para revisión manual. No se aplicaron correcciones automáticas ni se presenta un resultado de mejora real.

El inventario sigue la relación entradas menos salidas y conserva `Virtual = suma de los tres hijos` y `Sitio = Main + Virtual`, sin contar los hijos dos veces. La serie medida introduce una deriva ficticia de −420 L al final del periodo para ilustrar una conciliación.

## Verificaciones realizadas

| Componente | Resultado |
|---|---|
| Relaciones de archivos | IDs únicos; equipos, grupos y destinos relacionados; fechas válidas; volúmenes positivos; niveles dentro de capacidades inventadas |
| OverfillSflSpy | Lector y motor: 33 equipos, 378 movimientos, 2 excesos que suman 87 L, 14 operaciones sin SFL, 0 equipos sin maestro |
| IntakeVersusDelivery | Lector y motor: 378 movimientos; ambos balances coinciden con la tabla anterior |
| SweeperAndMop | Lector y motor con códigos de demo configurados temporalmente: 3 casos de flujo detectados, 4 hallazgos de maestro, 8 hallazgos totales |
| Fleet Maintenance | Lectores: 42 formularios, 32 TAG/SMU y 12 filas históricas; fechas, tablas nativas y valores calculados verificados |
| HMI | Parser puro: 5 tipos de archivo reconocidos; con topología ficticia adaptada en memoria, 168 movimientos dentro del alcance, 113 timestamps de stock y 1.685 lecturas; deriva de −420 L; sin errores de ejecución de reglas |
| Libros XLSX | Generados con Artifact Tool, recalculados, inspeccionados y revisados visualmente; metadato nativo de rango usado añadido para compatibilidad con el lector de Fleet |

HMI analiza únicamente la topología de almacenamiento. Los 224 despachos desde los camiones móviles quedan fuera de su alcance por diseño; sí se conservan y validan en los otros analizadores. No se ejecutaron las interfaces gráficas originales ni sus bases locales durante estas pruebas.

Estas cifras explican una demostración técnica. No describen la operación, resultados, ahorros, productividad ni experiencia laboral medidos del candidato.
